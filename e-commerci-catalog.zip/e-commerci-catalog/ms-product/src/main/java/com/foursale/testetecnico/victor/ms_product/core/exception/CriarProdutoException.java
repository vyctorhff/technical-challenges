package com.foursale.testetecnico.victor.ms_product.core.exception;

public class CriarProdutoException extends ApplicationException {

    public CriarProdutoException(String message) {
        super(message);
    }
}
