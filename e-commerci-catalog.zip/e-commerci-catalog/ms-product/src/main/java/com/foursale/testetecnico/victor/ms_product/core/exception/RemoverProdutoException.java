package com.foursale.testetecnico.victor.ms_product.core.exception;

public class RemoverProdutoException extends ApplicationException {

    public RemoverProdutoException(String message) {
        super(message);
    }
}
