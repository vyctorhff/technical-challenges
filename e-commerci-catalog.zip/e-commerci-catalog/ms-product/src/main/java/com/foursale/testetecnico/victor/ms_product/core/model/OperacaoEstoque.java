package com.foursale.testetecnico.victor.ms_product.core.model;

public enum OperacaoEstoque {
    CRIAR, ATUALIZAR, REMOVER
}
