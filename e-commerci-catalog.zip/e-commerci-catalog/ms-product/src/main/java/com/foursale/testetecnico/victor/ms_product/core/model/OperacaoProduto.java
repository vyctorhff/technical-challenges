package com.foursale.testetecnico.victor.ms_product.core.model;

public enum OperacaoProduto {
    CRIACAO, ATUALIZACAO, REMOCAO;
}
