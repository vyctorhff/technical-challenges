package com.foursale.testetecnico.victor.ms_product.core.exception;

public class EnviarProdutoException extends ApplicationException {
  public EnviarProdutoException(String message) {
    super(message);
  }
}
