rootProject.name = "ms-product"
