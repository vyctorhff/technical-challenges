package com.foursale.testetecnico.victor.ms_pedido.core.model;

public enum PedidoStatus {
    PENDENTE, CANCELADO, DISPONIVEL_ENTREGA, FINALIZADO;
}
