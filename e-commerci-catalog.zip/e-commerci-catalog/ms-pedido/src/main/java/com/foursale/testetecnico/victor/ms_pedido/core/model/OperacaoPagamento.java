package com.foursale.testetecnico.victor.ms_pedido.core.model;

public enum OperacaoPagamento {
    CRIACAO, ATUALIZACAO, REMOCAO;
}
