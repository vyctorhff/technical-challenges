package com.foursale.testetecnico.victor.ms_pedido.core.model;

import lombok.Data;

import java.util.UUID;

@Data
public class Usuario {
    private UUID id;
}
