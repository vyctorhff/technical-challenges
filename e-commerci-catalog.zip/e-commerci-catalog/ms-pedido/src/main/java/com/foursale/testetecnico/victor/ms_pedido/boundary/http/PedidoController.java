package com.foursale.testetecnico.victor.ms_pedido.boundary.http;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/pedido")
public class PedidoController {
}
