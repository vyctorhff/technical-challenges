package com.foursale.testetecnico.victor.ms_pedido.core.model;

public enum OperacaoEstoque {
    CRIAR, ATUALIZAR, REMOVER
}
