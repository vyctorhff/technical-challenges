package com.foursale.testetecnico.victor.ms_pedido.core.exception;

public class CriarPedidoException extends ApplicationException {
    public CriarPedidoException(String message) {
        super(message);
    }
}
