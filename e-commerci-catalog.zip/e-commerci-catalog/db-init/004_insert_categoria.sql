INSERT INTO tb_categoria
(id, nome, dt_criacao, dt_atualizacao)
VALUES
(UUID_TO_BIN(UUID()), 'Informática', NOW(), NOW());

INSERT INTO tb_categoria
(id, nome, dt_criacao, dt_atualizacao)
VALUES
(UUID_TO_BIN(UUID()), 'Games', NOW(), NOW());

INSERT INTO tb_categoria
(id, nome, dt_criacao, dt_atualizacao)
VALUES
(UUID_TO_BIN(UUID()), 'Eletrodomésticos', NOW(), NOW());
