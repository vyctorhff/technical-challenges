package com.foursale.testetecnico.victor.ms_pagamento.core.exception;

public class CriarPagamentoException extends ApplicationException {
    public CriarPagamentoException(String message) {
        super(message);
    }
}
