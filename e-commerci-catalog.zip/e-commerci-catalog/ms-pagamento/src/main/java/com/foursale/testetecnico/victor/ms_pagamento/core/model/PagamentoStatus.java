package com.foursale.testetecnico.victor.ms_pagamento.core.model;

public enum PagamentoStatus {
    PENDENTE, PAGO;
}
