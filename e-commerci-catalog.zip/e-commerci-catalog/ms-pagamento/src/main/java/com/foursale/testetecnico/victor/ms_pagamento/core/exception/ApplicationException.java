package com.foursale.testetecnico.victor.ms_pagamento.core.exception;

public class ApplicationException extends RuntimeException {
    public ApplicationException(String message) {
        super(message);
    }
}
