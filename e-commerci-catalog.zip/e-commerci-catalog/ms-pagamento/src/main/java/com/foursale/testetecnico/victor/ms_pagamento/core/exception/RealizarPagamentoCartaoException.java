package com.foursale.testetecnico.victor.ms_pagamento.core.exception;

public class RealizarPagamentoCartaoException extends ApplicationException {
    public RealizarPagamentoCartaoException(String message) {
        super(message);
    }
}
