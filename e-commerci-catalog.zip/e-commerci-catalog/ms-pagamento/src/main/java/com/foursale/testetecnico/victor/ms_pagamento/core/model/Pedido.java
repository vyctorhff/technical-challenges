package com.foursale.testetecnico.victor.ms_pagamento.core.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class Pedido {

    private UUID id;
}
