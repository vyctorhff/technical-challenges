package com.foursale.testetecnico.victor.ms_pagamento.boundary.async.body;

import java.util.UUID;

public record EventoPedigoPagoBody (UUID idPedido) {
}
