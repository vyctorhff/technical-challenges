package com.foursale.testetecnico.victor.ms_relatorio.boundary.http.dtos;

public record FaturamentoUltimoMesResponseDTO (
        Double valor
) {
}
