package com.foursale.testetecnico.victor.ms_relatorio.core.application.ports;

import com.foursale.testetecnico.victor.ms_relatorio.core.model.PedidoRelatorio;

public interface PedidoRelatorioRepository {

    void salvar(PedidoRelatorio pedidoRelatorio);
}
