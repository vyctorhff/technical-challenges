package com.foursale.testetecnico.victor.ms_produto_busca.core.model;

public enum OperacaoProduto {
    CRIACAO, ATUALIZACAO, REMOCAO;
}
