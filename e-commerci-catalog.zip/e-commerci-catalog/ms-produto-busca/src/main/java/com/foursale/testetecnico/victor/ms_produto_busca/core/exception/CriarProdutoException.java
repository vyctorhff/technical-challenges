package com.foursale.testetecnico.victor.ms_produto_busca.core.exception;

public class CriarProdutoException extends RuntimeException {
    public CriarProdutoException(String message) {
        super(message);
    }
}
