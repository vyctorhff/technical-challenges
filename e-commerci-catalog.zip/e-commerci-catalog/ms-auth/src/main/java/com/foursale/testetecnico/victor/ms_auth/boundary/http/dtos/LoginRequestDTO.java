package com.foursale.testetecnico.victor.ms_auth.boundary.http.dtos;

public record LoginRequestDTO(String nome, String password) {
}
