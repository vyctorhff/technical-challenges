package com.foursale.testetecnico.victor.ms_auth.core.exceptions;

public class ApplicationException extends RuntimeException {
  public ApplicationException(String message) {
    super(message);
  }
}
