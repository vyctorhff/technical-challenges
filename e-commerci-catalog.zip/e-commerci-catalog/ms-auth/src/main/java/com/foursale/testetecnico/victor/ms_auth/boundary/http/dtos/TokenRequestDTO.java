package com.foursale.testetecnico.victor.ms_auth.boundary.http.dtos;

public record TokenRequestDTO(Integer enrollment, String refresh) {
}
