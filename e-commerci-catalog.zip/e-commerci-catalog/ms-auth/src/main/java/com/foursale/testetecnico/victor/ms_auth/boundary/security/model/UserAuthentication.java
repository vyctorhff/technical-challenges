package com.foursale.testetecnico.victor.ms_auth.boundary.security.model;

import com.foursale.testetecnico.victor.ms_auth.core.model.PerfilEnum;
import com.foursale.testetecnico.victor.ms_auth.core.model.Usuario;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Data
public class UserAuthentication implements UserDetails {

    private Usuario user;

    public UserAuthentication(Usuario user) {
        this.user = user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (PerfilEnum.ADMIN.getName().equals(user.getNome())) {
            return List.of(
                    new SimpleGrantedAuthority("admin")
            );
        }

        return List.of(
                new SimpleGrantedAuthority("user")
        );
    }

    @Override
    public String getPassword() {
        return user.getPass();
    }

    @Override
    public String getUsername() {
        return String.valueOf(user.getNome());
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
