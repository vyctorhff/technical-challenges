package com.foursale.testetecnico.victor.ms_auth.core.exceptions;

public class GerarJwtException extends ApplicationException {
    public GerarJwtException(String message) {
        super(message);
    }
}
