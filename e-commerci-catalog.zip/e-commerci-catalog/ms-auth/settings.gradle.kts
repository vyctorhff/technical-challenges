rootProject.name = "ms-auth"
